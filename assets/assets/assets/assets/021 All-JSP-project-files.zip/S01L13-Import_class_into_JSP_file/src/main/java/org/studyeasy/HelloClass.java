package org.studyeasy;

public class HelloClass {
	public String demo() {
		return "Hello World";
	}

}
